<?php
    $names = array("Ram", "Sita", "Luv", "Kush");
    echo "$names[0] is husband of $names[1] and having sons $names[2] and $names[3]";
?>
