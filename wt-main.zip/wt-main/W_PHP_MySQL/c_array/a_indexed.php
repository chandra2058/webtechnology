<?php
    $names = array("Ram","Sita","Hari","Gita","Nita","Mina");

    foreach ($names as $name) {
        echo $name."<br/>";
    }
?>