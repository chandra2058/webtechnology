<?php
    $marks = array(
        "Ram" => array(
            "Nepali" => 45,
            "English" => 5,
            "Maths" => 95
        ),
        "Sita" => array(
            "Nepali" => 65,
            "English" => 55,
            "Maths" => 5
        ),
        "Hari" => array(
            "Nepali" => 35,
            "English" => 5,
            "Maths" => 67
        )
    );
    echo $marks["Ram"]["Nepali"];
?>