<?php
    $nums = [10,3,4,5,56,77,889,40,1];

    $nums_count = count($nums);

    for ($i=0; $i <$nums_count ; $i++) { 
        echo $nums[$i]."<br/>";
    }
?>