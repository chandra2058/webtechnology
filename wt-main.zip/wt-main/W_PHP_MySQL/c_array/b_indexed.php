<?php
    $names[0] = "Ram";
    $names[1] = "Sita";
    $names[2] = "Hari";
    $names[3] = "Gita";
    $names[4] = "Nita";
    $names[5] = "Mina";
    $names[6] = "Tina";
    $names[7] = "Gina";

    foreach ($names as $name) {
        echo $name."<br/>";
    }
?>