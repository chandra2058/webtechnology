<?php
    function add($a, $b)
    {
        return ($a + $b);
    }

    $x = 89;
    $y = 74;
    $result = add($x, $y);
    echo "The sum = $result";
?>