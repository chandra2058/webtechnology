<?php
    $names = serialize(array("Ram","Sita","Laxman"));
    echo $names;
?>