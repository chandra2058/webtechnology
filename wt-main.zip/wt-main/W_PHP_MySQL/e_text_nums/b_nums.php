<?php
    $num = 203;
    printf ("Binary equivalent = %b<br>", $num);
    printf ("Decimal equivalent = %d <br>",$num);
    printf ("Octal equivalent = %o <br>",$num);
    printf ("Double equivalent = %f <br>",$num);
?>