<?php
    // working with text and numbers in PHP
    echo "------------------------------------------------------<br>";
    echo "Working with TEXT and NUMBERS in PHP<br>";
    echo "------------------------------------------------------<br>";

    // echo and print statement does not work with comma
    /* echo "Hi friends ", "How are you ?";
    print "Hi friends ", "How are you ?"; */

    // working examples with . dot operator
    echo "Hi friends ". "How are you ?<br>";
    print "Hi friends ". "How are you ?<br>";

    // echo and print statements are use to display the result but echo is much faster than print and recomendded to use

    // displaying double quote statements with escape operator
    echo "He said- \"I love you very much.\" ";

?>