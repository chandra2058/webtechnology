<?php
    $value = sprintf("%.3f",45.63897458256);
    echo "Round off the value ".$value;
?>