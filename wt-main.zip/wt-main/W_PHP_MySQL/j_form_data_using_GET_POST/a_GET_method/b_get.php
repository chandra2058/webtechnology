<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Working with get method in PHP</title>
</head>
<body>
    <form action="get_process.php" method="GET">
        <input type="text" name="username" placeholder="Enter username">
        <input type="submit" value="Submit" name="submit">
    </form>
</body>
</html>