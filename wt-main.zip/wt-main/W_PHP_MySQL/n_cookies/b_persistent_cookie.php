<?php
setcookie("login","Sita Rai", time()+24*60*60*10); // persistent cookie