<?php
setcookie("loginuser", "Ram Thapa"); // session cookie