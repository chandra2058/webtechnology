<?php
setcookie("loginuser","Ram Thapa", time()-3600); // destroying cookies