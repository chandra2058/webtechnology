<?php
    $name = "HELLO, Sanothimi";
    $result = strtoupper($name);
    echo $result;
?>