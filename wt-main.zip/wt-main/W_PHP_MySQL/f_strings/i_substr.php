<?php
    $text = "hellosanothimi";
    $trimone = substr($text, 3);
    $trimtwo = substr($text, 3,5);
    echo $trimone."<br/>";
    echo $trimtwo;
?>