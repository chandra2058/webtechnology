<?php
    // capitalize each word
    $name = "ram thapa";
    echo ucwords($name);
?>