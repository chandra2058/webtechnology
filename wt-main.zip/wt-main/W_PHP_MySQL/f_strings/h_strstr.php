<?php
    $college = "sanothimi";
    if(strstr($college,"sano")){
        echo "Substring found.";
    }
    else
    {
        echo "Something went wrong.";
    }
?>