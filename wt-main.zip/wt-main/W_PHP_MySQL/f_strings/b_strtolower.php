<?php
    $name = "HELLO, Sanothimi";
    $result = strtolower($name);
    echo $result;
?>