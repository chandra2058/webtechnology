<?php
    $username = "ram";
    $password = "password1";
    if(($username =="ram") && ($password=="password1") && strlen($password) > 8)
    {
        echo "Hello ".$username;
    }
    else
    {
        echo "Timi ta arkai manxe parexau.";
    }
?>