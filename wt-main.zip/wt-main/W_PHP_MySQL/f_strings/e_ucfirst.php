<?php
    $name = "hello, Sanothimi";
    $result = ucfirst($name);
    echo $result;
?>