<?php
    $college = "sanothimi";
    $strlength = strlen($college);
    echo $strlength;
?>