<?php
    $name = "HELLO, Sanothimi";
    $result = lcfirst($name);
    echo $result;
?>