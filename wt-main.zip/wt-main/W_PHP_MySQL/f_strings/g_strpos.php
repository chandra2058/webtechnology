<?php
    $college = "Sanothimi";
    echo strpos($college,"th");
?>