<?php
    $name = "Sita";
    echo "Hello ".$name;
?>