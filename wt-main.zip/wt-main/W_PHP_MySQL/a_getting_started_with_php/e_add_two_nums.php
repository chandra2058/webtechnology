<?php
    $a = 10;
    $b = 20;
    $sum = $a + $b;
    echo "The sum of ".$a." and ".$b." is = ".$sum;
?>