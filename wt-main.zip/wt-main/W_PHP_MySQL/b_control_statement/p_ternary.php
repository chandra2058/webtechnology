<?php
    $age = 19;

    // condition ? True Value : False Value
    $result = $age > 17?"Voter":"Non-voter";
    echo $result;
?>