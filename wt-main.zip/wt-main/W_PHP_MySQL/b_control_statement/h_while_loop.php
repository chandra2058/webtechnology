<?php
    $a = 1; // initialization
    while ($a <= 10) {  // condition
        echo $a."<br/>";  // statement to print
        $a++; // increment or decrement
    }
?>