<?php
for ($i = 2; $i <= 20; $i += 2) {
    echo $i . "<br/>";
}
?>