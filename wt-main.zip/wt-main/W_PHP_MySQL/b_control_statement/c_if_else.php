<?php
    $age = 12;
    if($age >= 18)
    {
        echo "You're eligible to get voter card";
    }
    else
    {
        echo "You're not eligible to get voter card"; 
    }
?>