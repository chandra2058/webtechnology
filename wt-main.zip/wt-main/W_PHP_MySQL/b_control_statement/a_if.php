<?php
    $age = 18;
    if($age > 17)
    {
        echo "You're eligible to get voter card";
    }
?>