<?php
    $letter = 'g';

    switch ($letter) {
        case 'a':
            echo "Apple";
            break;
        case 'b':
            echo "Ball";
            break;
        case 'c':
            echo "Cat";
            break;
        case 'd':
            echo "Dog";
            break;
        case 'e':
            echo "Elephant";
            break;
        case 'f':
            echo "Flag";
            break;
        case 'g':
            echo "Ghost";
            break;
        
        default:
            echo "Invalid input";
            break;
    }
?>