<?php
    $a = 10; // initialization
    do{
        echo $a."<br/>";  // statement to print
        $a--; // increment or decrement
    }while ($a >= 1);  // condition
?>