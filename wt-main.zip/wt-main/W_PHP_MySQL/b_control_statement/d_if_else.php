<?php
    $gender = 'male';
    if($gender == 'female')
    {
        echo "Hello mistress";
    }
    else
    {
        echo "Hello Mister";
    }
?>