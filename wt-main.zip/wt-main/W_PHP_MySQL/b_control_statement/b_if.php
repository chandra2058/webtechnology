<?php
    $gender = 'female';
    if($gender == 'female')
    {
        echo "Hello mistress";
    }
?>