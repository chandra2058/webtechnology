let date_today = new Date();
document.body.innerHTML = "<h1>Today's date is " + date_today + "</h1>";